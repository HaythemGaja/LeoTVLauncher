# Leo TV Launcher 3.0

A native Android TV launcher for Android 7 and later. Home combines a quick-launch card, recently opened apps and pinned apps or folders. The Apps library includes all visible apps and supports searching by original or custom name.

Use the D-pad to navigate, OK to open and hold OK on a grid tile to organize. From the content edge, move toward the sidebar to select a section. Move away from the sidebar to return to your last tile. On Home, Back clears a search, returns to the sidebar, then returns to Home. On a utility screen Back returns to the previous screen.

Settings groups appearance, app layout, family controls, system shortcuts and backups. Home and Settings are always reachable. Other destinations can be shown or hidden in **Layout & apps → Customize sidebar**. The launcher follows the device language and layout direction. Core navigation, search and setting labels support English and Arabic.

Launcher shortcuts honor app and folder PINs and the Kids-mode allowlist. Protected apps never auto-start on boot. These controls apply to launches from Leo. JSON backups made by this version include the current custom wallpaper. Restore validates the file before applying settings and requests the configured PINs. Version 1 backups did not carry wallpaper images.

## Build and test

Run the bundled GitHub Actions **Build APK** workflow, or build locally with a JDK, Android platform 34, build-tools 34.0.0 and a standard Android debug keystore. Point `ANDROID_HOME` at your SDK and `LEO_KEYSTORE` at the keystore. The original sibling SDK, JDK and keystore layout is also supported.

```sh
bash tests/run-tests.sh
bash build-apk.sh
```

The build produces `build/out/LeoTVLauncher.apk` (version code 16). To install over an existing version, sign it with the same key. The included CI workflow generates a temporary debug key for each run.
