package com.leo.tvlauncher;

/** Determines the next step for every launch initiated by Leo. */
final class LaunchPolicy {
    enum Step { BLOCK, VERIFY_FOLDER, VERIFY_APP, OPEN }

    static Step next(boolean allowed, boolean folderPinNeeded, boolean appLocked,
                     boolean atBoot, long elapsed, long timeout) {
        if (!allowed) return Step.BLOCK;
        if (folderPinNeeded) return atBoot ? Step.BLOCK : Step.VERIFY_FOLDER;
        if (appLocked && (atBoot || timeout <= 0 || elapsed < 0 || elapsed >= timeout))
            return atBoot ? Step.BLOCK : Step.VERIFY_APP;
        return Step.OPEN;
    }
}
