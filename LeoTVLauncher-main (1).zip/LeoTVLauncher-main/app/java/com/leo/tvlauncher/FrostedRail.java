package com.leo.tvlauncher;

import android.app.Activity;
import android.graphics.*;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;

/** Samples the static wallpaper behind the rail. Text, icons and focus rings stay sharp. */
final class FrostedRail extends Drawable {
    private final Activity host;
    private final View rail;
    private final Theme theme;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Path clip = new Path();
    private final RectF panel = new RectF();
    private Bitmap frost;
    private int sourceWidth, sourceHeight, sourceX, sourceY;

    FrostedRail(Activity host, View rail, Theme theme) {
        this.host = host;
        this.rail = rail;
        this.theme = theme;
    }

    @Override protected void onBoundsChange(Rect bounds) {
        panel.set(bounds);
        clip.reset();
        float radius = Theme.dp(host, 25);
        clip.addRoundRect(panel, radius, radius, Path.Direction.CW);
        frost = null;
    }

    private void sample(int width, int height, int left, int top) {
        int factor = Theme.dp(host, 8);
        int w = Math.max(1, Math.round(panel.width() / factor));
        int h = Math.max(1, Math.round(panel.height() / factor));
        frost = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(frost);
        c.scale(w / panel.width(), h / panel.height());
        c.translate(-left, -top);
        ImageView wallpaper = host.findViewById(R.id.home_wallpaper);
        if (wallpaper != null && wallpaper.isShown() && wallpaper.getDrawable() instanceof BitmapDrawable) {
            Bitmap image = ((BitmapDrawable) wallpaper.getDrawable()).getBitmap();
            float scale = Math.max((float) width / image.getWidth(), (float) height / image.getHeight());
            float dx = (width - scale * image.getWidth()) / 2;
            float dy = (height - scale * image.getHeight()) / 2;
            paint.setColor(Color.WHITE);
            c.drawBitmap(image, null, new RectF(dx, dy, width - dx, height - dy), paint);
        } else {
            Drawable backdrop = Glass.wallpaper(theme);
            backdrop.setBounds(0, 0, width, height);
            backdrop.draw(c);
        }
        int[] pixels = new int[w * h];
        int[] intermediate = new int[pixels.length];
        frost.getPixels(pixels, 0, w, 0, 0, w, h);
        blur(pixels, intermediate, w, h, true);
        blur(intermediate, pixels, w, h, false);
        frost.setPixels(pixels, 0, w, 0, 0, w, h);
    }

    private static void blur(int[] source, int[] dest, int w, int h, boolean horizontal) {
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int red = 0, green = 0, blue = 0;
            for (int offset = -2; offset <= 2; offset++) {
                int sx = horizontal ? Math.min(w - 1, Math.max(0, x + offset)) : x;
                int sy = horizontal ? y : Math.min(h - 1, Math.max(0, y + offset));
                int color = source[sy * w + sx];
                red += Color.red(color);
                green += Color.green(color);
                blue += Color.blue(color);
            }
            dest[y * w + x] = Color.rgb(red / 5, green / 5, blue / 5);
        }
    }

    @Override public void draw(Canvas c) {
        View content = host.findViewById(android.R.id.content);
        int w = content.getWidth(), h = content.getHeight();
        if (w <= 0 || h <= 0 || panel.isEmpty()) return;
        int left = rail.getLeft() + (int) panel.left;
        int top = rail.getTop() + (int) panel.top;
        if (frost == null || w != sourceWidth || h != sourceHeight || left != sourceX || top != sourceY) {
            sample(w, h, left, top);
            sourceWidth = w; sourceHeight = h; sourceX = left; sourceY = top;
        }
        c.save();
        c.clipPath(clip);
        paint.setColor(Color.WHITE);
        c.drawBitmap(frost, null, panel, paint);
        paint.setColor(Glass.light(theme) ? 0xc9f7f6fc : 0xac232639);
        c.drawRect(panel, paint);
        paint.setColor(Glass.light(theme) ? 0x80ffffff : 0x52dbd9f5);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Theme.dp(host, 2));
        c.drawPath(clip, paint);
        paint.setStyle(Paint.Style.FILL);
        c.restore();
    }

    @Override public void setAlpha(int alpha) {}
    @Override public void setColorFilter(ColorFilter filter) {}
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
