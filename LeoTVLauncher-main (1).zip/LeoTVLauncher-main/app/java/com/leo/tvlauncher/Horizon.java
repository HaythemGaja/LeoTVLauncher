package com.leo.tvlauncher;

import android.graphics.*;
import android.graphics.drawable.Drawable;

/** Static, resolution-independent artwork for the Home feature card. */
final class Horizon extends Drawable {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Theme theme;
    private android.graphics.Picture scene;

    Horizon(Theme theme) { this.theme = theme; }

    @Override protected void onBoundsChange(Rect bounds) {
        int w = bounds.width(), h = bounds.height();
        if (w <= 0 || h <= 0) return;
        scene = new Picture();
        Canvas c = scene.beginRecording(w, h);
        c.scale(w / 1000f, h / 300f);
        int horizon = "forest".equals(theme.id) ? 0xffa1c8af :
                "ocean".equals(theme.id) ? 0xff91d0df : 0xffe8b2ad;
        paint.setShader(new LinearGradient(670, 0, 720, 265, new int[]{
                0xff34385c, 0xff777aab, horizon, 0xff8c748e}, null, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, 1000, 300, paint);
        paint.setShader(new RadialGradient(767, 119, 104,
                new int[]{0xaaffdfc0, 0x50ffe0ce, 0x00ffc4ac}, null, Shader.TileMode.CLAMP));
        c.drawCircle(767, 119, 104, paint);
        paint.setShader(null);
        paint.setColor(0xffffe4cb);
        c.drawCircle(767, 119, 25, paint);
        ridge(c, 0xff79728e, new int[]{0,159, 111,149, 200,180, 351,104, 425,134,
                546,86, 623,137, 717,115, 811,151, 914,103, 1000,124});
        ridge(c, 0xff545a7b, new int[]{0,190, 92,143, 143,153, 226,120, 402,193,
                508,156, 552,169, 605,144, 652,158, 713,139, 832,184, 930,140, 1000,116});
        ridge(c, 0xff343d60, new int[]{0,205, 125,167, 239,208, 303,182, 413,209,
                532,171, 609,190, 652,179, 746,208, 808,181, 877,166, 942,129, 1000,145});
        ridge(c, 0xff252d49, new int[]{0,201, 117,183, 231,220, 346,207, 448,236,
                567,212, 648,227, 713,217, 769,224, 835,202, 896,200, 951,180, 1000,174});
        paint.setColor(-1);
        paint.setShader(new LinearGradient(0, 0, 700, 0,
                new int[]{0xf9161e34,0xdc1c233c,0x00293250}, null, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, 1000, 300, paint);
        paint.setShader(null);
        scene.endRecording();
    }

    private void ridge(Canvas canvas, int color, int[] points) {
        Path path = new Path();
        path.moveTo(0, 300);
        for (int i = 0; i < points.length; i += 2) path.lineTo(points[i], points[i+1]);
        path.lineTo(1000, 300);
        path.close();
        paint.setColor(color);
        canvas.drawPath(path, paint);
    }

    @Override public void draw(Canvas c) {
        if (scene != null) c.drawPicture(scene);
    }
    @Override public void setAlpha(int alpha) {}
    @Override public void setColorFilter(ColorFilter filter) {}
    @Override public int getOpacity() { return PixelFormat.OPAQUE; }
}
