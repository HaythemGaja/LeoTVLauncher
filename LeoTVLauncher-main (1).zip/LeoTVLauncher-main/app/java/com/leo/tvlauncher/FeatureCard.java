package com.leo.tvlauncher;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.StateListDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

/** Quick access to a real installed app, with a fallback into the app library. */
final class FeatureCard extends FrameLayout {
    FeatureCard(Context c, Theme t, AppEntry entry, boolean recent, OnClickListener click) {
        super(c);
        setFocusable(true);
        setClickable(true);
        setTag("feature");
        setBackground(Theme.surface(c, 0xff26334c, 0, 0));
        setClipToOutline(true);
        View landscape = new View(c);
        landscape.setBackground(new Horizon(t));
        addView(landscape, new LayoutParams(-1, -1));
        // Mirror only the illustration. The darker area remains behind the leading text.
        if (c.getResources().getConfiguration().getLayoutDirection() == View.LAYOUT_DIRECTION_RTL)
            landscape.setScaleX(-1f);
        LinearLayout copy = new LinearLayout(c);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setGravity(Gravity.CENTER_VERTICAL);
        copy.setPaddingRelative(Theme.dp(c, 26), Theme.dp(c, 10), Theme.dp(c, 26), Theme.dp(c, 10));
        String title = entry == null ? c.getString(R.string.apps) : HomePrefs.displayLabel(c, entry);
        TextView caption = text(c, c.getString(recent ? R.string.last_opened : R.string.quick_pick), 13);
        caption.setTextColor(0xffdedcf1);
        caption.setLetterSpacing(.08f);
        if (entry != null && entry.icon != null) {
            android.graphics.drawable.Drawable icon = entry.icon.getConstantState() == null ? null
                    : entry.icon.getConstantState().newDrawable(c.getResources()).mutate();
            if (icon != null) {
                int size = Theme.dp(c, 23);
                icon.setBounds(0, 0, size, size);
                caption.setGravity(Gravity.CENTER_VERTICAL);
                caption.setCompoundDrawablesRelative(icon, null, null, null);
                caption.setCompoundDrawablePadding(Theme.dp(c, 8));
            }
        }
        copy.addView(caption);
        TextView name = text(c, title, 32);
        name.setTypeface(Typeface.create("sans-serif-medium", 0));
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        copy.addView(name);
        String action = c.getString(entry == null ? R.string.browse_apps : R.string.open_app);
        TextView pill = text(c, action, 14);
        pill.setTextColor(0xff1a2035);
        pill.setBackground(Theme.surface(c, 0xfff3effa, 0, 0));
        pill.setPadding(Theme.dp(c, 16), Theme.dp(c, 5), Theme.dp(c, 16), Theme.dp(c, 5));
        LinearLayout.LayoutParams chip = new LinearLayout.LayoutParams(-2, -2);
        chip.topMargin = Theme.dp(c, 10);
        copy.addView(pill, chip);
        addView(copy, new LayoutParams(-1, -1));
        setContentDescription(title + ", " + action);
        setOnClickListener(click);
        StateListDrawable outline = new StateListDrawable();
        outline.addState(new int[]{android.R.attr.state_focused},
                Theme.surface(c, 0, 0xfff9f6ff, Theme.focusWidth(c)));
        setForeground(outline);
        Theme.focusMotion(this, 1.012f);
    }

    private static TextView text(Context c, String value, int size) {
        TextView t = new TextView(c);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(-1);
        t.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        return t;
    }
}
