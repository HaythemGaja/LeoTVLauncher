package com.leo.tvlauncher;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/** Validates the entire archive before publishing its preferences and wallpaper together. */
final class BackupUtil {
    private static final String APP = "leo-tv-launcher";
    private static final int IMAGE_LIMIT = 8 * 1024 * 1024;
    static final int ARCHIVE_LIMIT = 16 * 1024 * 1024;

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("leo_tv_launcher", Context.MODE_PRIVATE);
    }

    static File wallpaper(Context c) {
        return imageFile(c, prefs(c).getBoolean("wall_slot", false));
    }

    private static File imageFile(Context c, boolean slot) {
        return new File(c.getFilesDir(), slot ? "wallpaper-next.jpg" : "wallpaper.jpg");
    }

    static byte[] readLimited(InputStream in, int max) throws IOException {
        if (in == null) throw new IOException("Missing file");
        try (InputStream input = in; ByteArrayOutputStream result = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) != -1) {
                if (result.size() + count > max) throw new IOException("File too large");
                result.write(buffer, 0, count);
            }
            return result.toByteArray();
        }
    }

    static JSONObject export(Context c) throws Exception {
        JSONObject data = new JSONObject();
        for (Map.Entry<String, ?> entry : prefs(c).getAll().entrySet()) {
            String key = entry.getKey();
            if ("last_unlock".equals(key) || "wall_slot".equals(key)) continue;
            Object value = entry.getValue();
            data.put(key, value instanceof Set ? new JSONArray((Set<?>) value) : value);
        }
        JSONObject out = new JSONObject().put("app", APP).put("v", 2).put("data", data);
        if (HomePrefs.wallpaperCustom(c)) {
            byte[] image = readLimited(new FileInputStream(wallpaper(c)), IMAGE_LIMIT);
            out.put("image", Base64.encodeToString(image, Base64.NO_WRAP));
        }
        return out;
    }

    private static void require(boolean condition) throws IOException {
        if (!condition) throw new IOException("Invalid backup");
    }

    private static String string(Object value) throws IOException {
        require(value instanceof String);
        return (String) value;
    }

    private static Set<String> strings(JSONArray array) throws Exception {
        Set<String> result = new HashSet<>();
        for (int i = 0; i < array.length(); i++) result.add(string(array.get(i)));
        return result;
    }

    private static void validateFolders(String value) throws Exception {
        JSONArray folders = new JSONArray(value);
        Set<String> ids = new HashSet<>(), packages = new HashSet<>();
        for (int i = 0; i < folders.length(); i++) {
            JSONObject folder = folders.getJSONObject(i);
            String id = string(folder.get("id"));
            require(!id.isEmpty() && ids.add(id));
            require(!string(folder.get("name")).trim().isEmpty());
            if (!folder.isNull("pin")) require(validToken(string(folder.get("pin"))));
            for (String pkg : strings(folder.getJSONArray("apps"))) require(packages.add(pkg));
        }
    }

    private static boolean validToken(String token) {
        return token.matches("[0-9a-fA-F]+:[0-9a-fA-F]{64}");
    }

    private static void assign(SharedPreferences.Editor ed, String key, Object value) throws Exception {
        switch (key) {
            case "hidden": case "locked_apps": case "sidebar_hidden":
                require(value instanceof JSONArray);
                ed.putStringSet(key, strings((JSONArray) value));
                return;
            case "kids_mode": case "settings_lock": case "reduce_motion": case "bold_focus":
                require(value instanceof Boolean);
                ed.putBoolean(key, (Boolean) value);
                return;
            case "icon_size": case "label_size": case "relock_min": case "pin_ver":
                require(value instanceof Integer);
                int n = (Integer) value;
                if ("icon_size".equals(key)) require(n >= 16 && n <= 160);
                if ("label_size".equals(key)) require(n == -1 || (n >= 10 && n <= 40));
                if ("relock_min".equals(key)) require(n >= 0 && n <= 1440);
                if ("pin_ver".equals(key)) require(n == 1 || n == 2);
                ed.putInt(key, n);
                return;
            case "fav_order": case "app_order": case "recents": case "sidebar_order": case "kids_apps":
                strings(new JSONArray(string(value)));
                break;
            case "custom_labels":
                JSONObject labels = new JSONObject(string(value));
                Iterator<String> names = labels.keys();
                while (names.hasNext()) string(labels.get(names.next()));
                break;
            case "folders_json":
                validateFolders(string(value));
                break;
            case "pin_hash":
                require(validToken(string(value)) || string(value).matches("[0-9a-fA-F]{64}"));
                break;
            case "wallpaper":
                require("theme".equals(value) || "custom".equals(value));
                break;
            case "theme_id":
                boolean themeFound = false;
                for (Theme t : Theme.PRESETS) if (t.id.equals(value)) themeFound = true;
                require(themeFound);
                break;
            case "icon_shape":
                require(java.util.Arrays.asList(Theme.SHAPES).contains(value));
                break;
            case "pin_salt": case "boot_app":
                break;
            case "last_unlock":
                return; // A backup never grants an active unlock session.
            default:
                throw new IOException("Unknown setting");
        }
        ed.putString(key, string(value));
    }

    static String importData(Context c, String json) {
        try {
            JSONObject backup = new JSONObject(json);
            require(APP.equals(backup.get("app")));
            Object version = backup.get("v");
            require(Integer.valueOf(1).equals(version) || Integer.valueOf(2).equals(version));
            JSONObject data = backup.getJSONObject("data");
            SharedPreferences.Editor ed = prefs(c).edit().clear();
            Iterator<String> keys = data.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                assign(ed, key, data.get(key));
            }
            if (data.optBoolean("kids_mode")) {
                require(validToken(data.optString("pin_hash")) && data.optInt("pin_ver") == 2);
            }
            boolean slot = prefs(c).getBoolean("wall_slot", false);
            if ("custom".equals(data.optString("wallpaper"))) {
                if (Integer.valueOf(1).equals(version)) {
                    if (!wallpaper(c).isFile()) ed.putString("wallpaper", "theme");
                } else {
                    byte[] bytes = Base64.decode(string(backup.get("image")), Base64.DEFAULT);
                    require(bytes.length > 0 && bytes.length <= IMAGE_LIMIT);
                    BitmapFactory.Options info = new BitmapFactory.Options();
                    info.inJustDecodeBounds = true;
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.length, info);
                    require(info.outWidth > 0 && info.outHeight > 0 &&
                            info.outWidth <= 3840 && info.outHeight <= 3840);
                    // Decode a thumbnail too, so an unreadable image header cannot replace a wallpaper.
                    info.inJustDecodeBounds = false;
                    info.inSampleSize = 8;
                    Bitmap sample = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, info);
                    require(sample != null);
                    sample.recycle();
                    slot = !slot;
                    try (FileOutputStream out = new FileOutputStream(imageFile(c, slot))) {
                        out.write(bytes);
                        out.getFD().sync();
                    }
                }
            }
            return ed.putBoolean("wall_slot", slot).commit() ? null : "Could not save settings";
        } catch (Exception e) {
            return "Invalid or unsupported backup";
        }
    }
}
