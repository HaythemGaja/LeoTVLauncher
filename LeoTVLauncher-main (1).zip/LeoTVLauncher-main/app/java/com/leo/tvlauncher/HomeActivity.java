package com.leo.tvlauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Lean, D-pad friendly TV home screen with a Roku-style left navigation bar. Plain GridLayout (no
 * GridView): every tile is a real focused view, so the remote's D-pad and OK button always work.
 * Long-press a tile to organize.
 */
public class HomeActivity extends Activity {

    private static final String NAV_TOKEN = java.util.UUID.randomUUID().toString();
    private static final int REQ_EXIT_KIDS = 100;

    public static final String EXTRA_VIEW = "extra_view";
    public static final String EXTRA_ACTION = "extra_action";

    private GridLayout grid;
    private ImageView wallpaperView;
    private TextView hintView;
    private TextView emptyView;
    private TextView recentHeader;
    private HorizontalScrollView recentScroller;
    private LinearLayout recentRow;
    private LinearLayout sidebarBox;
    private Sidebar sidebar;
    private View root;
    private final Handler clockHandler = new Handler();
    private final List<Integer> favTileIndices = new ArrayList<>();
    private long lastHomePress = 0;
    private Theme theme;
    private int currentView = Sidebar.VIEW_HOME;
    // Live move mode state.
    private String movingPkg = null;
    private List<String> movingSnapshot = null;
    private int gridCols = 4;
    private int measuredGridWidth = -1;
    private final Map<String, AppEntry> catalog = new HashMap<>();
    private String lastFocusedTag;
    private String query = "";
    private final android.util.SparseArray<String> contentFocus = new android.util.SparseArray<>();
    private AppEntry featured;
    private android.widget.FrameLayout featureHost;
    private View search;


    private final Runnable clockTick =
            new Runnable() {
                @Override
                public void run() {
                    if (sidebar != null) sidebar.tick();
                    clockHandler.postDelayed(this, 30000);
                }
            };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        root = findViewById(R.id.home_root);
        grid = findViewById(R.id.app_grid);
        sidebarBox = findViewById(R.id.sidebar);
        wallpaperView = findViewById(R.id.home_wallpaper);
        hintView = findViewById(R.id.home_hint);
        emptyView = findViewById(R.id.empty_view);
        recentHeader = findViewById(R.id.recent_header);
        recentScroller = findViewById(R.id.recent_scroller);
        recentRow = findViewById(R.id.recent_row);
        featureHost = findViewById(R.id.feature_host);
        search = findViewById(R.id.search_button);
        search.setTag("search");
        search.setOnClickListener(v -> searchApps());
        if (savedInstanceState != null) {
            currentView = savedInstanceState.getInt("view", Sidebar.VIEW_HOME);
            query = savedInstanceState.getString("query", "");
            lastFocusedTag = savedInstanceState.getString("focus");
            contentFocus.put(currentView, savedInstanceState.getString("content"));
        }
        grid.setClipChildren(false);
        grid.setClipToPadding(false);
        grid.addOnLayoutChangeListener(
                new View.OnLayoutChangeListener() {
                    @Override
                    public void onLayoutChange(
                            View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
                        int width = AppTiles.available(grid);
                        if (width > 1 && width != measuredGridWidth) {
                            measuredGridWidth = width;
                            buildGrid();
                        }
                    }
                });
        handleNavExtras(getIntent());
    }

    /** Jump to a sidebar view or trigger a sidebar action from another screen. */
    public static void goTo(android.content.Context c, int view, int action) {
        Intent i = new Intent(c, HomeActivity.class);
        i.putExtra("navigation_token", NAV_TOKEN);
        i.putExtra(EXTRA_VIEW, view);
        i.putExtra(EXTRA_ACTION, action);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        c.startActivity(i);
    }

    /** Applies "view"/"action" extras sent by goTo(). */
    private void handleNavExtras(Intent intent) {
        if (intent == null || !NAV_TOKEN.equals(intent.getStringExtra("navigation_token"))) return;
        intent.removeExtra("navigation_token");
        int view = intent.getIntExtra(EXTRA_VIEW, -1);
        int action = intent.getIntExtra(EXTRA_ACTION, Sidebar.ACT_NONE);
        intent.removeExtra(EXTRA_VIEW);
        intent.removeExtra(EXTRA_ACTION);
        if (view >= 0) {
            currentView = view;
            if (sidebar != null) {
                sidebar.setSelectedId(Sidebar.idForView(view));
                sidebar.build();
            }
            if (theme != null) { buildFeature(); buildGrid(); buildRecentRow(); }
        }
        if (action != Sidebar.ACT_NONE) handleAction(action);
    }

    @Override
    protected void onResume() {
        super.onResume();
        reload();
        clockTick.run();
        // Focus the first tile so the D-pad works immediately.
        grid.post(
                new Runnable() {
                    @Override
                    public void run() {
                        if (grid.getChildCount() > 0 && getCurrentFocus() == null) {
                            grid.getChildAt(0).requestFocus();
                        }
                    }
                });
    }

    private void reload() {
        View oldFocus = getCurrentFocus();
        if (oldFocus != null && oldFocus.getTag() instanceof String)
            lastFocusedTag = (String) oldFocus.getTag();
        theme = Theme.current(this);
        root.setBackground(Glass.wallpaper(theme));
        boolean kids = HomePrefs.kidsMode(this);
        recentHeader.setTextColor(theme.text);
        recentHeader.setText(R.string.recently_opened);
        recentHeader.setTextSize(20);
        recentHeader.setLetterSpacing(0);
        recentScroller.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        recentScroller.setElevation(0);
        recentScroller.setPadding(
                Theme.dp(this, 10), Theme.dp(this, 6), Theme.dp(this, 10), Theme.dp(this, 2));
        hintView.setTextColor(theme.text2);
        emptyView.setTextColor(theme.text2);
        hintView.setText(movingPkg != null ? R.string.moving_hint : kids ? R.string.kids_hint : R.string.normal_hint);
        catalog.clear();
        for (AppEntry e : Apps.query(this)) catalog.put(e.pkg, e);
        applyWallpaper();
        View scrim = findViewById(R.id.wallpaper_scrim);
        scrim.setVisibility(
                wallpaperView.getVisibility() == View.VISIBLE ? View.VISIBLE : View.GONE);
        int rgb = theme.bg & 0x00FFFFFF;
        android.graphics.drawable.GradientDrawable sideShade =
                new android.graphics.drawable.GradientDrawable(
                        android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                        new int[] {rgb | 0xA0000000, rgb | 0x40000000});
        android.graphics.drawable.GradientDrawable lowerShade =
                new android.graphics.drawable.GradientDrawable(
                        android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                        new int[] {rgb | 0x30000000, rgb | 0x80000000});
        scrim.setBackground(
                new android.graphics.drawable.LayerDrawable(
                        new android.graphics.drawable.Drawable[] {sideShade, lowerShade}));
        sidebar =
                new Sidebar(
                        this,
                        sidebarBox,
                        Sidebar.idForView(currentView),
                        new Sidebar.Listener() {
                            @Override
                            public void onView(int view) {
                                onSidebarView(view);
                            }

                            @Override
                            public void onAction(int action) {
                                handleAction(action);
                            }
                        });
        sidebar.build();
        search.setVisibility(kids ? View.GONE : View.VISIBLE);
        ((android.widget.Button) search).setTextColor(theme.text);
        ((android.widget.Button) search).setAllCaps(false);
        search.setBackground(Theme.tileBackground(this, theme));
        buildFeature();
        buildGrid();
        buildRecentRow();
        if (lastFocusedTag != null) {
            if (lastFocusedTag.startsWith("side:")) sidebar.focusItem(lastFocusedTag.substring(5));
            else if (lastFocusedTag.startsWith("recent:")) {
                View previous = recentRow.findViewWithTag(lastFocusedTag);
                if (previous != null) previous.requestFocus();
            } else if ("feature".equals(lastFocusedTag) || "search".equals(lastFocusedTag)) {
                View target = root.findViewWithTag(lastFocusedTag);
                if (target != null && target.isShown()) target.requestFocus();
            } else focusTile(lastFocusedTag);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        clockHandler.removeCallbacks(clockTick);
        if (movingPkg != null) exitMoveMode(true);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (movingPkg != null && event.getAction() == KeyEvent.ACTION_DOWN) {
            int kc = event.getKeyCode();
            int dir = 0;
            if (kc == KeyEvent.KEYCODE_DPAD_LEFT) dir = -1;
            else if (kc == KeyEvent.KEYCODE_DPAD_RIGHT) dir = 1;
            else if (kc == KeyEvent.KEYCODE_DPAD_UP) dir = -gridCols;
            else if (kc == KeyEvent.KEYCODE_DPAD_DOWN) dir = gridCols;
            else if (kc == KeyEvent.KEYCODE_DPAD_CENTER
                    || kc == KeyEvent.KEYCODE_ENTER
                    || kc == KeyEvent.KEYCODE_BUTTON_A) {
                exitMoveMode(true);
                return true;
            } else if (kc == KeyEvent.KEYCODE_BACK) {
                exitMoveMode(false);
                return true;
            }
            if (dir != 0) {
                moveSelected(dir);
                return true;
            }
        }
        if (event.getAction() == KeyEvent.ACTION_DOWN && !HomePrefs.kidsMode(this)) {
            View focused = getCurrentFocus();
            boolean rtl = root.getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
            int towardMenu = rtl ? KeyEvent.KEYCODE_DPAD_RIGHT : KeyEvent.KEYCODE_DPAD_LEFT;
            int towardApps = rtl ? KeyEvent.KEYCODE_DPAD_LEFT : KeyEvent.KEYCODE_DPAD_RIGHT;
            if (focused != null && event.getKeyCode() == towardMenu && !sidebarBox.hasFocus()) {
                View next = focused.focusSearch(rtl ? View.FOCUS_RIGHT : View.FOCUS_LEFT);
                boolean edge = grid.indexOfChild(focused) >= 0 && grid.indexOfChild(focused) % gridCols == 0;
                if (edge || next == null || isMenuItem(next) || featureHost.hasFocus()
                        || recentRow.indexOfChild(focused) == 0) {
                    rememberContent();
                    sidebar.focusSelected();
                    return true;
                }
            } else if (focused != null && event.getKeyCode() == towardApps && sidebarBox.hasFocus()) {
                focusContent();
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    private boolean isMenuItem(View view) {
        Object tag = view.getTag();
        return tag instanceof String && ((String) tag).startsWith("side:");
    }

    private void rememberContent() {
        View v = getCurrentFocus();
        if (v != null && !isMenuItem(v) && v.getTag() instanceof String)
            contentFocus.put(currentView, (String) v.getTag());
    }

    private void focusContent() {
        String tag = contentFocus.get(currentView);
        View previous = tag == null ? null : root.findViewWithTag(tag);
        if (previous != null && previous.isShown() && previous.requestFocus()) return;
        if (featureHost.getVisibility() == View.VISIBLE && featureHost.getChildCount() > 0)
            featureHost.getChildAt(0).requestFocus();
        else if (grid.getChildCount() > 0) grid.getChildAt(0).requestFocus();
        else if (search.isShown()) search.requestFocus();
        else sidebar.focusSelected();
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        rememberContent();
        state.putInt("view", currentView);
        state.putString("content", contentFocus.get(currentView));
        state.putString("query", query);
        View v = getCurrentFocus();
        if (v != null && v.getTag() instanceof String) state.putString("focus", (String) v.getTag());
    }

    @Override public void onBackPressed() {
        if (movingPkg != null) { exitMoveMode(false); return; }
        if (HomePrefs.kidsMode(this)) { sidebar.focusSelected(); return; }
        if (!query.isEmpty() && currentView == Sidebar.VIEW_APPS) {
            query = "";
            buildGrid();
            focusContent();
        } else if (!sidebarBox.hasFocus()) {
            rememberContent();
            sidebar.focusSelected();
        } else if (currentView != Sidebar.VIEW_HOME) {
            onSidebarView(Sidebar.VIEW_HOME);
        } else if (!Apps.isDefaultHome(this)) {
            super.onBackPressed();
        } else focusContent();
    }

    private void searchApps() {
        if (HomePrefs.kidsMode(this)) return;
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint(R.string.app_name_hint);
        input.setText(query);
        input.selectAll();
        android.app.AlertDialog dialog = Theme.dialog(this).setTitle(R.string.search_apps)
                .setView(input).setNegativeButton(android.R.string.cancel, null)
                .setPositiveButton(R.string.search, (d, which) -> {
                    query = input.getText().toString().trim();
                    onSidebarView(Sidebar.VIEW_APPS);
                    focusContent();
                }).create();
        input.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        input.setOnEditorActionListener((v, action, event) -> {
            if (action != android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH) return false;
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).performClick();
            return true;
        });
        dialog.show();
        input.requestFocus();
    }

    private void buildFeature() {
        featureHost.removeAllViews();
        featured = null;
        boolean visible = currentView == Sidebar.VIEW_HOME && !HomePrefs.kidsMode(this);
        featureHost.setVisibility(visible ? View.VISIBLE : View.GONE);
        if (!visible) return;
        Set<String> hidden = HomePrefs.hidden(this);
        java.util.List<String> candidates = new ArrayList<>(HomePrefs.recents(this));
        candidates.addAll(HomePrefs.favOrder(this));
        for (String pkg : candidates) {
            if (catalog.containsKey(pkg) && !hidden.contains(pkg) && Apps.protectedFolder(this, pkg) == null) {
                featured = catalog.get(pkg);
                break;
            }
        }
        final AppEntry chosen = featured;
        FeatureCard card = new FeatureCard(this, theme, chosen,
                chosen != null && HomePrefs.recents(this).contains(chosen.pkg), v -> {
                    if (chosen == null) { onSidebarView(Sidebar.VIEW_APPS); focusContent(); }
                    else Apps.openApp(this, chosen);
                });
        featureHost.addView(card);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (NAV_TOKEN.equals(intent.getStringExtra("navigation_token"))) {
            handleNavExtras(intent);
            return;
        }
        if (Intent.ACTION_MAIN.equals(intent.getAction()) && currentView != Sidebar.VIEW_HOME)
            onSidebarView(Sidebar.VIEW_HOME);
        // Double-press of Home jumps to favorites.
        long now = System.currentTimeMillis();
        if (now - lastHomePress < 800 && !favTileIndices.isEmpty()) {
            final int idx = favTileIndices.get(0);
            grid.post(
                    new Runnable() {
                        @Override
                        public void run() {
                            if (idx < grid.getChildCount()) grid.getChildAt(idx).requestFocus();
                        }
                    });
        }
        lastHomePress = now;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_EXIT_KIDS && resultCode == RESULT_OK) {
            HomePrefs.setKidsMode(this, false);
            Toast.makeText(this, "Kids mode off", Toast.LENGTH_SHORT).show();
            reload();
        }
    }

    private void applyWallpaper() {
        wallpaperView.setImageDrawable(null);
        wallpaperView.setVisibility(View.GONE);
        if (!HomePrefs.wallpaperCustom(this)) return;
        File f = BackupUtil.wallpaper(this);
        if (!f.exists()) return;
        Bitmap b = decodeSampled(f.getAbsolutePath(), 1920);
        if (b != null) {
            wallpaperView.setImageBitmap(b);
            wallpaperView.setVisibility(View.VISIBLE);
        }
    }

    static Bitmap decodeSampled(String path, int maxDim) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, o);
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / sample > maxDim) sample *= 2;
            o.inJustDecodeBounds = false;
            o.inSampleSize = sample;
            return BitmapFactory.decodeFile(path, o);
        } catch (Exception e) {
            return null;
        }
    }

    // --- Left navigation bar (built by the shared Sidebar helper) ---

    private void onSidebarView(int view) {
        rememberContent();
        if (view != Sidebar.VIEW_APPS) query = "";
        currentView = view;
        if (sidebar != null) {
            String id = Sidebar.idForView(view);
            sidebar.setSelectedId(id);
            sidebar.build();
            sidebar.focusItem(id);
        }
        buildFeature();
        buildGrid();
        buildRecentRow();
    }

    /** Handles a sidebar action id (also used by goTo() from other screens). */
    private void handleAction(int action) {
        if (HomePrefs.kidsMode(this) && action != Sidebar.ACT_EXIT_KIDS) return;
        if (action == Sidebar.ACT_LOCK) {
            Intent i = new Intent(this, PinActivity.class);
            i.putExtra(
                    "mode", PinStore.hasPin(this) ? PinActivity.MODE_VERIFY : PinActivity.MODE_SET);
            startActivity(i);
        } else if (action == Sidebar.ACT_KIDS) {
            enterKidsMode();
        } else if (action == Sidebar.ACT_SETTINGS) {
            if (HomePrefs.settingsLocked(this) && PinStore.hasPin(this)) {
                Intent i = new Intent(this, PinActivity.class);
                i.putExtra("mode", PinActivity.MODE_VERIFY_SETTINGS);
                startActivity(i);
            } else {
                startActivity(new Intent(this, SettingsActivity.class));
            }
        } else if (action == Sidebar.ACT_NOTIFICATIONS) {
            startActivity(new Intent(this, NotificationsActivity.class));
        } else if (action == Sidebar.ACT_QUICK_SETTINGS) {
            startActivity(new Intent(this, QuickSettingsActivity.class));
        } else if (action == Sidebar.ACT_EXIT_KIDS) {
            Intent i = new Intent(this, PinActivity.class);
            i.putExtra("mode", PinActivity.MODE_VERIFY_EXIT_KIDS);
            startActivityForResult(i, REQ_EXIT_KIDS);
        }
    }

    // --- Content grid ---

    private void buildGrid() {
        View focused = getCurrentFocus();
        String restoreTag =
                focused != null && focused.getTag() instanceof String
                        ? (String) focused.getTag()
                        : lastFocusedTag;
        grid.removeAllViews();
        favTileIndices.clear();
        if (AppTiles.available(grid) <= 1) return; // Wait for the actual post-sidebar measurement.
        int cols = AppTiles.columns(this, grid);
        grid.setColumnCount(cols);
        gridCols = cols;

        List<AppEntry> tiles = new ArrayList<>();
        Set<String> hidden = HomePrefs.hidden(this);
        Map<String, AppEntry> byPkg = new HashMap<>();
        for (AppEntry e : catalog.values()) {
            e.favorite = HomePrefs.isFav(this, e.pkg);
            byPkg.put(e.pkg, e);
        }
        boolean kids = HomePrefs.kidsMode(this);

        if (kids) {
            for (String pkg : HomePrefs.kidsApps(this)) {
                AppEntry e = byPkg.get(pkg);
                if (e != null) tiles.add(e);
            }
        } else if (currentView == Sidebar.VIEW_APPS) {
            List<String> appOrder = HomePrefs.getList(this, "app_order");
            boolean updated = false;
            for (AppEntry e : sortedCatalog()) {
                if (!e.favorite && !appOrder.contains(e.pkg)) {
                    appOrder.add(e.pkg);
                    updated = true;
                }
            }
            if (updated) HomePrefs.setList(this, "app_order", appOrder);
            java.util.LinkedHashSet<String> ordered = new java.util.LinkedHashSet<>(HomePrefs.favOrder(this));
            ordered.addAll(appOrder);
            for (AppEntry e : sortedCatalog()) ordered.add(e.pkg);
            String term = query.toLowerCase(java.util.Locale.ROOT);
            for (String pkg : ordered) {
                AppEntry e = catalog.get(pkg);
                if (e == null || hidden.contains(pkg)) continue;
                String names = HomePrefs.displayLabel(this, e) + " " + e.label;
                if (names.toLowerCase(java.util.Locale.ROOT).contains(term)) tiles.add(e);
            }
        } else if (currentView == Sidebar.VIEW_FAVORITES) {
            for (String pkg : HomePrefs.favOrder(this)) {
                AppEntry e = byPkg.get(pkg);
                if (e != null && !hidden.contains(pkg)) {
                    e.favorite = true;
                    tiles.add(e);
                }
            }
            if (!tiles.isEmpty()) favTileIndices.add(0);
        } else if (currentView == Sidebar.VIEW_RECENT) {
            for (String pkg : HomePrefs.recents(this)) {
                AppEntry e = byPkg.get(pkg);
                if (e != null && !hidden.contains(pkg)) {
                    tiles.add(e);
                }
            }
        } else if (currentView == Sidebar.VIEW_FOLDERS) {
            for (FolderStore.Folder f : FolderStore.getFolders(this)) {
                AppEntry fe = new AppEntry();
                fe.folderId = f.id;
                fe.label = f.name;
                tiles.add(fe);
            }
        } else {
            // Home: favorites first, then folders, then the rest.
            List<String> favOrder = HomePrefs.favOrder(this);
            for (String pkg : favOrder) {
                AppEntry e = byPkg.get(pkg);
                if (e != null && !hidden.contains(pkg) && FolderStore.folderOf(this, pkg) == null) {
                    e.favorite = true;
                    favTileIndices.add(tiles.size());
                    tiles.add(e);
                }
            }

            for (FolderStore.Folder f : FolderStore.getFolders(this)) {
                AppEntry fe = new AppEntry();
                fe.folderId = f.id;
                fe.label = f.name;
                tiles.add(fe);
            }

            List<String> order = HomePrefs.getList(this, "app_order");
            boolean orderChanged = false;
            for (AppEntry e : sortedCatalog()) {
                if (!hidden.contains(e.pkg)
                        && FolderStore.folderOf(this, e.pkg) == null
                        && !favOrder.contains(e.pkg)
                        && !order.contains(e.pkg)) {
                    order.add(e.pkg);
                    orderChanged = true;
                }
            }
            if (orderChanged) HomePrefs.setList(this, "app_order", order);
            boolean showUnpinned = tiles.isEmpty();
            for (String pkg : order) {
                if (!showUnpinned) break;
                AppEntry e = byPkg.get(pkg);
                if (e != null
                        && !hidden.contains(pkg)
                        && FolderStore.folderOf(this, pkg) == null
                        && !favOrder.contains(pkg)) {
                    tiles.add(e);
                }
            }
        }

        gridCols =
                TileMetrics.homeColumns(
                        AppTiles.available(grid),
                        getResources().getDisplayMetrics().density,
                        Theme.iconSizeDp(this),
                        tiles.size());
        grid.setColumnCount(gridCols);
        for (AppEntry e : tiles) grid.addView(makeTile(e));
        if (restoreTag != null && (focused == null || !restoreTag.startsWith("side:")))
            focusTile(restoreTag);
        TextView title = findViewById(R.id.home_title);
        String screen = kids ? "Kids mode" : Sidebar.defaultItem(Sidebar.idForView(currentView)).label;
        title.setText(Labels.get(this, screen));
        TextView section = findViewById(R.id.section_title);
        section.setTextColor(theme.text);
        boolean grouped = currentView == Sidebar.VIEW_HOME && !kids && !tiles.isEmpty();
        boolean results = currentView == Sidebar.VIEW_APPS && !query.isEmpty() && !kids;
        section.setVisibility(grouped || results ? View.VISIBLE : View.GONE);
        if (grouped) {
            boolean pinned = !favTileIndices.isEmpty() || !FolderStore.getFolders(this).isEmpty();
            section.setText(pinned ? R.string.pinned : R.string.your_apps);
        } else if (results) section.setText(getString(R.string.results_for, query));
        title.setTextColor(theme.text);
        title.setTextSize(36);
        title.setTypeface(android.graphics.Typeface.create("sans-serif-medium", 0));

        if (tiles.isEmpty()) {
            emptyView.setVisibility(View.VISIBLE);
            if (kids) emptyView.setText(R.string.no_kids);
            else if (currentView == Sidebar.VIEW_FAVORITES) emptyView.setText(R.string.no_favs);
            else if (currentView == Sidebar.VIEW_RECENT) emptyView.setText(R.string.no_recent);
            else if (currentView == Sidebar.VIEW_FOLDERS) emptyView.setText(R.string.no_folders);
            else {
                emptyView.setText(query.isEmpty() ? R.string.no_apps : R.string.no_matches);
            }
        } else {
            emptyView.setVisibility(View.GONE);
        }
    }

    private String tileTag(AppEntry e) {
        if (e.folderId != null) return "folder:" + e.folderId;
        if (e.pkg != null) return "pkg:" + e.pkg;
        return "tile:" + e.label;
    }

    private List<AppEntry> sortedCatalog() {
        List<AppEntry> result = new ArrayList<>(catalog.values());
        java.util.Collections.sort(
                result,
                new java.util.Comparator<AppEntry>() {
                    @Override
                    public int compare(AppEntry a, AppEntry b) {
                        return a.label.compareToIgnoreCase(b.label);
                    }
                });
        return result;
    }

    private View makeTile(final AppEntry e) {
        int width = TileMetrics.width(AppTiles.available(grid), gridCols, Theme.dp(this, 8));
        View v = AppTiles.create(this, e, width, catalog);
        v.setTag(tileTag(e));
        AppTiles.sizeGridTile(this, v, AppTiles.available(grid), gridCols);
        if (movingPkg != null && movingPkg.equals(e.pkg))
            v.setBackground(Theme.movingTileBackground(this, theme));
        v.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        lastFocusedTag = tileTag(e);
                        handleTileClick(e);
                    }
                });
        v.setOnLongClickListener(
                new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View view) {
                        lastFocusedTag = tileTag(e);
                        return onTileLongPress(e);
                    }
                });
        return v;
    }

    private void buildRecentRow() {
        recentRow.removeAllViews();
        // The recent strip only appears on the Home view; the Recent view
        // shows the same apps as full-size tiles.
        boolean show = !HomePrefs.kidsMode(this) && currentView == Sidebar.VIEW_HOME;
        if (show) {
            Set<String> hidden = HomePrefs.hidden(this);
            Map<String, AppEntry> byPkg = new HashMap<>();
            for (AppEntry e : catalog.values()) byPkg.put(e.pkg, e);
            List<AppEntry> recents = new ArrayList<>();
            for (String pkg : HomePrefs.recents(this)) {
                AppEntry e = byPkg.get(pkg);
                if (e != null && !hidden.contains(pkg)) {
                    if (featured == null || !pkg.equals(featured.pkg)) recents.add(e);
                }
            }
            for (AppEntry e : recents) recentRow.addView(makeRecentTile(e));
            show = !recents.isEmpty();
        }
        recentHeader.setVisibility(show ? View.VISIBLE : View.GONE);
        recentScroller.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    private void refreshCollections() {
        buildFeature();
        buildGrid();
        buildRecentRow();
    }

    private View makeRecentTile(final AppEntry e) {
        int width = Theme.dp(this, 136);
        View v = AppTiles.create(this, e, width, catalog);
        v.setTag("recent:" + e.pkg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(width, -2);
        lp.setMargins(Theme.dp(this, 8), Theme.dp(this, 8), Theme.dp(this, 8), Theme.dp(this, 12));
        v.setLayoutParams(lp);
        v.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        lastFocusedTag = "recent:" + e.pkg;
                        Apps.openApp(HomeActivity.this, e);
                    }
                });
        return v;
    }

    private void handleTileClick(AppEntry e) {
        if (e.folderId != null) {
            Intent i = new Intent(this, FolderActivity.class);
            i.putExtra("folder_id", e.folderId);
            startActivity(i);

        } else {
            Apps.openApp(this, e);
        }
    }

    private void enterKidsMode() {
        if (!PinStore.hasPin(this)) {
            Toast.makeText(
                            this,
                            "Set a PIN first — it's needed to exit kids mode",
                            Toast.LENGTH_LONG)
                    .show();
            Intent i = new Intent(this, PinActivity.class);
            i.putExtra("mode", PinActivity.MODE_SET);
            startActivity(i);
            return;
        }
        if (HomePrefs.kidsApps(this).isEmpty()) {
            Toast.makeText(
                            this,
                            "Choose kids apps first: sidebar → Settings → Kids mode",
                            Toast.LENGTH_LONG)
                    .show();
            handleAction(Sidebar.ACT_SETTINGS);
            return;
        }
        HomePrefs.setKidsMode(this, true);
        Toast.makeText(this, "Kids mode on", Toast.LENGTH_SHORT).show();
        reload();
    }

    // --- Long-press organize ---

    private boolean onTileLongPress(final AppEntry e) {
        if (HomePrefs.kidsMode(this)) return false;
        String protectedId = e.folderId != null && FolderStore.hasPin(this, e.folderId)
                ? e.folderId : (e.pkg == null ? null : Apps.protectedFolder(this, e.pkg));
        if (protectedId != null) {
            Intent open = new Intent(this, FolderActivity.class);
            open.putExtra("folder_id", protectedId);
            startActivity(open);
            return true;
        }
        if (e.folderId != null) {
            showFolderMenu(e);
            return true;
        }
        showAppOrganizeMenu(e, currentView != Sidebar.VIEW_RECENT && query.isEmpty()
                && (HomePrefs.isFav(this, e.pkg) || FolderStore.folderOf(this, e.pkg) == null));
        return true;
    }

    private void showAppOrganizeMenu(final AppEntry e, boolean allowMove) {
        final boolean fav = HomePrefs.isFav(this, e.pkg);
        final boolean locked = PinStore.hasPin(this) && PinStore.lockedApps(this).contains(e.pkg);
        final boolean hasFolders = !FolderStore.getFolders(this).isEmpty();
        List<String> items = new ArrayList<>();
        if (allowMove) items.add("Move app");
        items.add(fav ? "★ Remove from favorites" : "☆ Add to favorites");
        items.add(locked ? "🔓 Manage app lock" : "🔒 Lock app");
        items.add("Create folder with this app");
        if (hasFolders) items.add("Add to folder…");
        if (!locked) items.add("🗑 Uninstall");
        items.add("Hide app");
        items.add("✏️ Rename");
        if (HomePrefs.recents(this).contains(e.pkg)) items.add("🕘 Remove from recent");
        if (!locked) items.add("App info");
        Theme.dialog(this)
                .setTitle(e.label)
                .setItems(
                        Labels.options(this, items.toArray(new String[0])),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                String item = items.get(which);
                                onOrganizeItem(e, item);
                            }
                        })
                .show();
    }

    private void onOrganizeItem(AppEntry e, String item) {
        if (item.equals("Move app")) {
            enterMoveMode(e);
        } else if (item.startsWith("★") || item.startsWith("☆")) {
            HomePrefs.setFav(this, e.pkg, !HomePrefs.isFav(this, e.pkg));
            refreshCollections();
            focusTile(tileTag(e));
            Toast.makeText(
                            this,
                            HomePrefs.isFav(this, e.pkg)
                                    ? "Added to favorites"
                                    : "Removed from favorites",
                            Toast.LENGTH_SHORT)
                    .show();
        } else if (item.startsWith("🔒") || item.startsWith("🔓")) {
            if (!PinStore.hasPin(this)) {
                Toast.makeText(this, "Set a PIN first (sidebar → App Lock)", Toast.LENGTH_LONG)
                        .show();
                Intent i = new Intent(this, PinActivity.class);
                i.putExtra("mode", PinActivity.MODE_SET);
                startActivity(i);
            } else {
                if (Apps.appLocked(this, e.pkg)) {
                    handleAction(Sidebar.ACT_LOCK);
                    return;
                }
                PinStore.setLocked(this, e.pkg, true);
                refreshCollections();
                focusTile(tileTag(e));
                Toast.makeText(
                                this,
                                e.label + " locked",
                                Toast.LENGTH_SHORT)
                        .show();
            }
        } else if (item.equals("Create folder with this app")) {
            promptNewFolder(e);
        } else if (item.equals("Add to folder…")) {
            promptAddToFolder(e);
        } else if (item.startsWith("🗑")) {
            uninstallApp(e);
        } else if (item.startsWith("✏️")) {
            promptRenameApp(e);
        } else if (item.startsWith("🕘")) {
            List<String> r = new ArrayList<>(HomePrefs.recents(this));
            r.remove(e.pkg);
            HomePrefs.setList(this, "recents", r);
            refreshCollections();
            Toast.makeText(this, e.label + " removed from recent", Toast.LENGTH_SHORT).show();
        } else if (item.equals("Hide app")) {
            HomePrefs.setHidden(this, e.pkg, true);
            refreshCollections();
            Toast.makeText(this, e.label + " hidden", Toast.LENGTH_SHORT).show();
        } else if (item.equals("App info")) {
            try {
                Intent i =
                        new Intent(
                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + e.pkg));
                startActivity(i);
            } catch (ActivityNotFoundException ex) {
                Toast.makeText(this, "App info not available", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void uninstallApp(AppEntry e) {
        Apps.uninstall(
                this,
                e.pkg,
                e.label,
                new Runnable() {
                    @Override
                    public void run() {
                        refreshCollections();
                    }
                });
    }

    private void promptRenameApp(final AppEntry e) {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        String cur = HomePrefs.customLabel(this, e.pkg);
        input.setText(cur != null ? cur : e.label);
        input.selectAll();
        Theme.dialog(this)
                .setTitle(R.string.new_name)
                .setView(input)
                .setPositiveButton(
                        R.string.save,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                HomePrefs.setCustomLabel(
                                        HomeActivity.this, e.pkg, input.getText().toString());
                                refreshCollections();
                            }
                        })
                .setNeutralButton(
                        R.string.reset,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                HomePrefs.setCustomLabel(HomeActivity.this, e.pkg, null);
                                refreshCollections();
                            }
                        })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    // --- Live move mode ---

    private String orderKeyFor(String pkg) {
        return HomePrefs.isFav(this, pkg) ? "fav_order" : "app_order";
    }

    private void enterMoveMode(AppEntry e) {
        movingSnapshot = new ArrayList<>(HomePrefs.getList(this, orderKeyFor(e.pkg)));
        movingPkg = e.pkg;
        hintView.setText(R.string.moving_hint);
        buildGrid();
        focusTile(tileTag(e));
    }

    private void moveSelected(int dir) {
        if (movingPkg == null) return;
        String key = orderKeyFor(movingPkg);
        List<String> l = HomePrefs.getList(this, key);
        int i = l.indexOf(movingPkg);
        if (i < 0) return;
        int j = i + dir;
        if (j < 0) j = 0;
        if (j >= l.size()) j = l.size() - 1;
        if (j == i) return;
        l.remove(i);
        l.add(j, movingPkg);
        HomePrefs.setList(this, key, l);
        buildGrid();
        focusTile("pkg:" + movingPkg);
    }

    private void exitMoveMode(boolean commit) {
        if (movingPkg == null) return;
        if (!commit && movingSnapshot != null) {
            HomePrefs.setList(this, orderKeyFor(movingPkg), movingSnapshot);
        }
        String tag = "pkg:" + movingPkg;
        movingPkg = null;
        movingSnapshot = null;
        reload();
        focusTile(tag);
    }

    private void promptNewFolder(final AppEntry e) {
        final EditText input = new EditText(this);
        input.setText("Folder " + FolderStore.nextFolderNumber(this));
        input.selectAll();
        Theme.dialog(this)
                .setTitle(R.string.new_folder)
                .setView(input)
                .setPositiveButton(
                        R.string.create,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                String name = input.getText().toString().trim();
                                if (name.isEmpty()) name = "Folder";
                                FolderStore.Folder f = FolderStore.create(HomeActivity.this, name);
                                FolderStore.moveTo(HomeActivity.this, e.pkg, f.id);
                                buildGrid();
                                Toast.makeText(
                                                HomeActivity.this,
                                                e.label + " moved to " + name,
                                                Toast.LENGTH_SHORT)
                                        .show();
                            }
                        })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void promptAddToFolder(final AppEntry e) {
        final List<FolderStore.Folder> folders = FolderStore.getFolders(this);
        String[] names = new String[folders.size()];
        for (int i = 0; i < folders.size(); i++) names[i] = folders.get(i).name;
        Theme.dialog(this)
                .setTitle(R.string.add_to_folder)
                .setItems(
                        names,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                FolderStore.Folder f = folders.get(which);
                                FolderStore.moveTo(HomeActivity.this, e.pkg, f.id);
                                buildGrid();
                                Toast.makeText(
                                                HomeActivity.this,
                                                e.label + " moved to " + f.name,
                                                Toast.LENGTH_SHORT)
                                        .show();
                            }
                        })
                .show();
    }

    private void showFolderMenu(final AppEntry e) {
        final FolderStore.Folder f = FolderStore.get(this, e.folderId);
        if (f == null) return;
        Theme.dialog(this)
                .setTitle(f.name)
                .setItems(
                        Labels.options(this, new String[] {"Rename folder", "Delete folder"}),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                if (which == 0) promptRenameFolder(f);
                                else confirmDeleteFolder(f);
                            }
                        })
                .show();
    }

    private void promptRenameFolder(final FolderStore.Folder f) {
        final EditText input = new EditText(this);
        input.setText(f.name);
        input.selectAll();
        Theme.dialog(this)
                .setTitle(R.string.rename_folder)
                .setView(input)
                .setPositiveButton(
                        R.string.save,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                String name = input.getText().toString().trim();
                                if (!name.isEmpty()) {
                                    FolderStore.rename(HomeActivity.this, f.id, name);
                                    buildGrid();
                                }
                            }
                        })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void confirmDeleteFolder(final FolderStore.Folder f) {
        Theme.dialog(this)
                .setTitle(R.string.confirm_delete)
                .setMessage("Apps inside will return to the home screen.")
                .setPositiveButton(
                        R.string.delete,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                FolderStore.delete(HomeActivity.this, f.id);
                                buildGrid();
                            }
                        })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void focusTile(final String tag) {
        grid.post(
                new Runnable() {
                    @Override
                    public void run() {
                        for (int i = 0; i < grid.getChildCount(); i++) {
                            if (tag.equals(grid.getChildAt(i).getTag())) {
                                grid.getChildAt(i).requestFocus();
                                return;
                            }
                        }
                    }
                });
    }
}
