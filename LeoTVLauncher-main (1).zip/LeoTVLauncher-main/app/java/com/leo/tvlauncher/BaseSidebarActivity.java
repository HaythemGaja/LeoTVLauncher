package com.leo.tvlauncher;

import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

/**
 * Base class for every settings-style screen (Settings, Manage apps,
 * Customize sidebar, Kids setup, Folders, Notifications). It keeps the
 * Roku-style sidebar visible so navigation is one D-pad press away,
 * with a live clock/date in the sidebar header.
 *
 * Subclasses call setSidebarContent(layoutRes) instead of setContentView,
 * then work with their views exactly as before.
 */
public abstract class BaseSidebarActivity extends Activity {

    private static final int REQ_EXIT_KIDS = 900;

    private LinearLayout sidebarBox;
    private Sidebar sidebar;
    private android.view.View previousContent;

    protected Theme theme;
    private final Handler clockHandler = new Handler();
    private final Runnable clockTick = new Runnable() {
        @Override public void run() {
            if (sidebar != null) sidebar.tick();
            clockHandler.postDelayed(this, 30000);
        }
    };

    protected void setSidebarContent(int layoutRes) {
        setContentView(R.layout.activity_sidebar_host);
        sidebarBox = findViewById(R.id.sidebar);
        FrameLayout content = findViewById(R.id.sidebar_content);
        getLayoutInflater().inflate(layoutRes, content, true);
    }

    /** The sidebar id to highlight on this screen ("settings", "folders", ...). */
    protected abstract String sidebarSelectedId();

    @Override
    protected void onResume() {
        super.onResume();
        theme = Theme.current(this);
        findViewById(R.id.sidebar_host_root).setBackgroundColor(theme.bg);
        sidebar = new Sidebar(this, sidebarBox, sidebarSelectedId(),
                new Sidebar.Listener() {
                    @Override public void onView(int view) {
                        HomeActivity.goTo(BaseSidebarActivity.this, view, Sidebar.ACT_NONE);
                    }
                    @Override public void onAction(int action) {
                        onSidebarAction(action);
                    }
                });
        sidebar.build();
        clockTick.run();
    }

    @Override
    protected void onPause() {
        super.onPause();
        clockHandler.removeCallbacks(clockTick);
    }

    @Override
    public boolean dispatchKeyEvent(android.view.KeyEvent event) {
        if (event.getAction() != android.view.KeyEvent.ACTION_DOWN || sidebar == null)
            return super.dispatchKeyEvent(event);
        android.view.View current = getCurrentFocus();
        boolean rtl = sidebarBox.getLayoutDirection() == android.view.View.LAYOUT_DIRECTION_RTL;
        int towardRail = rtl ? android.view.KeyEvent.KEYCODE_DPAD_RIGHT : android.view.KeyEvent.KEYCODE_DPAD_LEFT;
        int intoContent = rtl ? android.view.KeyEvent.KEYCODE_DPAD_LEFT : android.view.KeyEvent.KEYCODE_DPAD_RIGHT;
        if (current != null && !sidebarBox.hasFocus() && event.getKeyCode() == towardRail) {
            android.view.View next = current.focusSearch(rtl ? android.view.View.FOCUS_RIGHT : android.view.View.FOCUS_LEFT);
            if (next == null || next.getTag() instanceof String && ((String) next.getTag()).startsWith("side:")) {
                previousContent = current;
                sidebar.focusSelected();
                return true;
            }
        } else if (sidebarBox.hasFocus() && event.getKeyCode() == intoContent) {
            if (previousContent != null && previousContent.isAttachedToWindow() && previousContent.isShown()
                    && previousContent.requestFocus()) return true;
            android.view.ViewGroup content = findViewById(R.id.sidebar_content);
            for (android.view.View v : content.getFocusables(android.view.View.FOCUS_FORWARD))
                if (v != content && v.isClickable() && v.requestFocus()) return true;
        }
        return super.dispatchKeyEvent(event);
    }

    /** Repaint the same fixed sidebar when appearance is applied in-place. */
    protected void refreshSidebarTheme() {
        if(sidebar!=null)sidebar.build();
    }

    protected void onSidebarAction(int action) {
        if (HomePrefs.kidsMode(this) && action != Sidebar.ACT_EXIT_KIDS) return;
        if (action == Sidebar.ACT_EXIT_KIDS) {
            Intent i = new Intent(this, PinActivity.class);
            i.putExtra("mode", PinActivity.MODE_VERIFY_EXIT_KIDS);
            startActivityForResult(i, REQ_EXIT_KIDS);
        } else if (action == Sidebar.ACT_SETTINGS && this instanceof SettingsActivity) {
            // Already on a settings screen; nothing to do.
        } else if (action == Sidebar.ACT_NOTIFICATIONS) {
            if (!(this instanceof NotificationsActivity)) HomeActivity.goTo(this, -1, action);
        } else if (action == Sidebar.ACT_QUICK_SETTINGS) {
            if (!(this instanceof QuickSettingsActivity)) HomeActivity.goTo(this, -1, action);
        } else {
            // Content views, App Lock and Kids mode all live in HomeActivity.
            HomeActivity.goTo(this, -1, action);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_EXIT_KIDS && resultCode == RESULT_OK) {
            HomePrefs.setKidsMode(this, false);
            HomeActivity.goTo(this, Sidebar.VIEW_HOME, Sidebar.ACT_NONE);
        }
    }
}
