package com.leo.tvlauncher;

public class LaunchPolicyTest {
    private static int checks;

    private static void expect(LaunchPolicy.Step expected, boolean allowed, boolean folder,
                               boolean locked, boolean boot, long age, long timeout) {
        LaunchPolicy.Step decision = LaunchPolicy.next(allowed, folder, locked, boot, age, timeout);
        if (expected != decision) throw new AssertionError(expected + " != " + decision);
        checks++;
    }

    public static void main(String[] args) {
        for (boolean folder : new boolean[]{false, true}) {
            for (boolean locked : new boolean[]{false, true}) {
                for (boolean boot : new boolean[]{false, true})
                    expect(LaunchPolicy.Step.BLOCK, false, folder, locked, boot, 0, 1000);
                expect(folder || locked ? LaunchPolicy.Step.BLOCK : LaunchPolicy.Step.OPEN,
                        true, folder, locked, true, 0, 1000);
            }
        }
        expect(LaunchPolicy.Step.VERIFY_FOLDER, true, true, true, false, 1000, 1000);
        expect(LaunchPolicy.Step.VERIFY_FOLDER, true, true, false, false, 0, 0);
        expect(LaunchPolicy.Step.VERIFY_APP, true, false, true, false, 1000, 1000);
        expect(LaunchPolicy.Step.OPEN, true, false, true, false, 999, 1000);
        expect(LaunchPolicy.Step.VERIFY_APP, true, false, true, false, -1, 1000);
        expect(LaunchPolicy.Step.VERIFY_APP, true, false, true, false, 0, 0);
        expect(LaunchPolicy.Step.OPEN, true, false, false, false, 1000, 0);
        System.out.println("Launch policy: " + checks + " checks passed");
    }
}
