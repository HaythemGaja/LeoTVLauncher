#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ -n "${JAVA_HOME:-}" ]]; then export PATH="$JAVA_HOME/bin:$PATH"; fi
if ! command -v javac >/dev/null && [[ -x ../jdk/bin/javac ]]; then export PATH="$PWD/../jdk/bin:$PATH"; fi
compiler=(javac)
if ! command -v javac >/dev/null; then compiler=(java -m jdk.compiler/com.sun.tools.javac.Main); fi
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
src=app/java/com/leo/tvlauncher
"${compiler[@]}" -d "$work" "$src/TileMetrics.java" tests/TileMetricsTest.java "$src/LaunchPolicy.java" tests/LaunchPolicyTest.java
java -cp "$work" TileMetricsTest
java -cp "$work" com.leo.tvlauncher.LaunchPolicyTest
python3 tests/check-access.py
python3 tests/check-home-glass.py
python3 tests/check-resources.py
