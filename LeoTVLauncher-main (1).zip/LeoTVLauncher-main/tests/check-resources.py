"""Check native layouts, resource references, and Arabic format placeholders without an SDK."""
import re
from pathlib import Path
from collections import defaultdict
import xml.etree.ElementTree as ET

app = Path(__file__).resolve().parent.parent / 'app'
resources = defaultdict(set)
strings = {}
for path in (app / 'res').glob('*/*'):
    group = path.parent.name.split('-')[0]
    if group != 'values':
        resources[group].add(path.stem)
    if path.suffix != '.xml':
        continue
    root = ET.parse(path).getroot()
    if group == 'values':
        for child in root:
            if path.parent.name == 'values':
                resources[child.get('type', child.tag)].add(child.get('name'))
            if child.tag == 'string':
                strings.setdefault(path.parent.name, {})[child.get('name')] = child.text
    resources['id'].update(re.findall(r'@\+id/(\w+)', path.read_text()))

for path in app.rglob('*'):
    if path.suffix not in ('.java', '.xml'):
        continue
    if path.suffix == '.xml':
        ET.parse(path)
    for group, name in re.findall(r'(?<!android\.)(?:\bR\.|@)(string|id|style|layout|color|drawable|mipmap)[./](\w+)', path.read_text()):
        assert name in resources[group], (path, group, name)
for name, value in strings['values-ar'].items():
    default = strings['values'][name]
    assert sorted(re.findall(r'%\d+\$[sd]', default)) == sorted(re.findall(r'%\d+\$[sd]', value)), name
print('Android resource references, XML and Arabic format placeholders passed')
